android_hangman
===============

Very basic Hangman game for Android. Works with API 19 or higher (KitKat 4.4). Simply download, open with Eclipse or 
Android Studio(Recommended) and compile.

# ToDo
Many things new to be added:

* Animations, instead of a hangman now it shows a score.
* Highest Score, keeping track of your progress.
* Retrieve words from external API and local DB instead of simple hardcodes values.
* Difficulty level selection.

# Images
![main window](http://i57.tinypic.com/ixv8tj.png)
